﻿'Title:Little League Baseball
'Author: Jason Fore
'Date:April 9, 2018
'Pripose: To display player ages between 12-14.Also being able to add and delete players in
'into the database.

Public Class frmLeague
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'LittleLeague2DataSet.Team' table. You can move, or remove it, as needed.
        Me.TeamTableAdapter.Fill(Me.LittleLeague2DataSet.Team)

    End Sub

    Private Sub TeamBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles TeamBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.TeamBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.LittleLeague2DataSet)

    End Sub
End Class
